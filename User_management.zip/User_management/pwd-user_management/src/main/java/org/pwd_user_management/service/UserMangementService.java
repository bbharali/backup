package org.pwd_user_management.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import javax.transaction.Transactional;

import org.pwd_user_management.contract.UserRequest;
import org.pwd_user_management.contract.UserResponse;
import org.pwd_user_management.entity.EmployeeAddress;
import org.pwd_user_management.entity.EmployeeOtherInfo;
import org.pwd_user_management.entity.EmployeeQualification;
import org.pwd_user_management.entity.MDesignation;
import org.pwd_user_management.entity.MDistrict;
import org.pwd_user_management.entity.MEmployee;
import org.pwd_user_management.entity.MOffice;
import org.pwd_user_management.entity.MPosting;
import org.pwd_user_management.entity.MUser;
import org.pwd_user_management.model.EmployeeAdressDetail;
import org.pwd_user_management.model.EmployeeOtherInfoDetails;
import org.pwd_user_management.model.EmployeePostingDetails;
import org.pwd_user_management.model.EmployeeQualificationDetails;
import org.pwd_user_management.repository.EmployeeOtherInfoRepository;
import org.pwd_user_management.repository.EmployeePostingRepo;
import org.pwd_user_management.repository.EmployeeQualificationRepo;
import org.pwd_user_management.repository.MDesignationRepository;
import org.pwd_user_management.repository.MDistrictRepository;
import org.pwd_user_management.repository.MEmployeeRepository;
import org.pwd_user_management.repository.MOfficeRepository;
import org.pwd_user_management.repository.UserRepository;
import org.pwd_user_management.web.errorhandlers.UserManagementException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Service;

@Service
public class UserMangementService {

	@Autowired
	UserRepository userRepo;

	@Autowired
	MEmployeeRepository empRepo;

	@Autowired
	EmployeeQualificationRepo equlaiRepo;

	@Autowired
	EmployeePostingRepo empPosstingrepo;

	@Autowired
	EmployeeOtherInfoRepository employeeOtherInforepo;
	@Autowired
	MOfficeRepository mofficeRepo;
	@Autowired
	MDistrictRepository districtRepo;
	@Autowired
	MDesignationRepository designationRepo;

	Set<Long> qualificationIdsToDelete = null;

	public void createUser(UserRequest userRequest, UserResponse userResponse) throws UserManagementException {
		MUser mUser = null;
		MEmployee mEmployee = null;
		boolean newUser = true;
		String userType = "";
		boolean userTypeEmployee = false;
		if (userRequest.getUserRequestDetail().getId() == null
				|| userRequest.getUserRequestDetail().getId().isEmpty()) {
			mUser = new MUser();
		} else {
			mUser = userRepo.findById(Long.parseLong(userRequest.getUserRequestDetail().getId()));
			if (null == mUser || mUser.getId() == null)
				throw new UserManagementException("Invalid User Id");

			newUser = false;
		}

		if (null == userRequest.getUserRequestDetail().getUserType()
				|| userRequest.getUserRequestDetail().getUserType().isEmpty()) {
			throw new UserManagementException("Usertype cannot be empty !!!");
		} else {
			userType = userRequest.getUserRequestDetail().getUserType();
			if (userType.equalsIgnoreCase("Employee")) {
				userTypeEmployee = true;
			}
		}

		mUser = primaryValidation(userRequest, mUser, newUser);
		if (newUser) {
			mUser = createUserName(mUser, userRequest);
		}

		if (!userTypeEmployee) {
			userRepo.save(mUser);
		}
		///////////////// Process EN Other Users

		else if (userTypeEmployee) {
			if (newUser)
				mEmployee = new MEmployee();
			else if (!newUser)
				mEmployee = empRepo.getEmployeeByUserId(mUser.getId());
			mEmployee = primaryEmployeeValidation(mEmployee, userRequest, newUser, mUser);
			mEmployee = primaryAddressValidation(mUser, userRequest, newUser, mEmployee);
			mEmployee = validateQualifiactionDetails(mEmployee, userRequest, newUser, mUser);
			try {
				mEmployee = validatePostingDetails(mEmployee, userRequest, newUser, mUser);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			mEmployee = validateOtherDetails(mEmployee, userRequest, newUser, mUser);
			mUser.setMEmployee(mEmployee);
			userRepo.save(mUser);

			if (qualificationIdsToDelete != null && qualificationIdsToDelete.size() > 0) {
				deleteEmployeeQulaificationById(qualificationIdsToDelete);
			}
		}
	}

	public MUser primaryValidation(UserRequest userRequest, MUser mUser, boolean newUser)
			throws UserManagementException {
		if (userRequest.getUserRequestDetail().getPrefix() == null
				|| userRequest.getUserRequestDetail().getPrefix().isEmpty()) {
			throw new UserManagementException("Prefix cannot be null!!");
		} else {
			mUser.setMprefix(userRequest.getUserRequestDetail().getPrefix());
		}
		if (userRequest.getUserRequestDetail().getFirstName() == null
				|| userRequest.getUserRequestDetail().getFirstName().isEmpty()) {
			throw new UserManagementException("First name cannot be empty !!!");
		} else {
			mUser.setFname(userRequest.getUserRequestDetail().getFirstName());
		}
		if (null != userRequest.getUserRequestDetail().getMiddleName()) {
			mUser.setMname(userRequest.getUserRequestDetail().getMiddleName());
		}

		if (userRequest.getUserRequestDetail().getLastName() == null
				|| userRequest.getUserRequestDetail().getLastName().isEmpty()) {
			throw new UserManagementException("Last name cannot be empty !!!");
		} else {
			mUser.setLname(userRequest.getUserRequestDetail().getLastName());
		}
		if (userRequest.getUserRequestDetail().getEmail() == null
				|| userRequest.getUserRequestDetail().getEmail().isEmpty()) {
			throw new UserManagementException("Email cannot be empty !!!");
		}
		if (null == userRequest.getUserRequestDetail().getPhoneNo()) {
			throw new UserManagementException("Phone number cannot be empty!!!");
		}
		if (userRequest.getUserRequestDetail().getPhoneNo().toString().length() < 10
				|| userRequest.getUserRequestDetail().getPhoneNo().toString().length() > 10) {
			throw new UserManagementException("Invalid mobile number digits!!!");
		}

		if (null == userRequest.getUserRequestDetail().getDob()
				|| userRequest.getUserRequestDetail().getDob().isEmpty()) {
			throw new UserManagementException("Date of Birth cannot be empty!!!");
		} else {
			mUser.setDob(userRequest.getUserRequestDetail().getDob());
		}
		if (null == userRequest.getUserRequestDetail().getUserType()
				|| userRequest.getUserRequestDetail().getUserType().isEmpty()) {
			throw new UserManagementException("Usertype cannot be empty !!!");
		} else {
			mUser.setUserType(userRequest.getUserRequestDetail().getUserType());
		}

		if (null != String.valueOf(userRequest.getUserRequestDetail().isActive())) {
			mUser.setActive(userRequest.getUserRequestDetail().isActive());
		} else {
			mUser.setActive(true);
		}
		mUser = secondaryValidation(mUser, userRequest, newUser);
		return mUser;
	}

	public MEmployee primaryEmployeeValidation(MEmployee mEmployee, UserRequest userRequest, boolean newUser,
			MUser mUser) throws UserManagementException {
		if (null != userRequest.getUserRequestDetail().getAddtionalDetails().getFatherName()
				&& !userRequest.getUserRequestDetail().getAddtionalDetails().getFatherName().isEmpty()) {
			mEmployee.setFatherName(userRequest.getUserRequestDetail().getAddtionalDetails().getFatherName());
		}
		if (null != userRequest.getUserRequestDetail().getAddtionalDetails().getUploadPhoto()) {
			mEmployee.setUploadPhoto(userRequest.getUserRequestDetail().getAddtionalDetails().getUploadPhoto());
		}
		if (null != userRequest.getUserRequestDetail().getAddtionalDetails().getRetirementDate()) {
			mEmployee.setRetirementDate(userRequest.getUserRequestDetail().getAddtionalDetails().getRetirementDate());
		}
		if (null != userRequest.getUserRequestDetail().getAddtionalDetails().getTownOfBirth()) {
			mEmployee.setTownOfBirth(userRequest.getUserRequestDetail().getAddtionalDetails().getTownOfBirth());
		}
		if (null != userRequest.getUserRequestDetail().getAddtionalDetails().getStateOfBirth()) {
			mEmployee.setTownOfBirth(userRequest.getUserRequestDetail().getAddtionalDetails().getStateOfBirth());
		}
		if (null != userRequest.getUserRequestDetail().getAddtionalDetails().getReligion()) {
			mEmployee.setReligion(userRequest.getUserRequestDetail().getAddtionalDetails().getReligion());
		}
		if (null != userRequest.getUserRequestDetail().getAddtionalDetails().getNationality()) {
			mEmployee.setNationality(userRequest.getUserRequestDetail().getAddtionalDetails().getNationality());
		}
		if (null != userRequest.getUserRequestDetail().getAddtionalDetails().getIdentification()) {
			mEmployee.setIdentification(userRequest.getUserRequestDetail().getAddtionalDetails().getIdentification());
		}
		if (null != userRequest.getUserRequestDetail().getAddtionalDetails().getBloodGroup()) {
			mEmployee.setBloodGroup(userRequest.getUserRequestDetail().getAddtionalDetails().getBloodGroup());
		}
		if (null != userRequest.getUserRequestDetail().getAddtionalDetails().getHeight()) {
			mEmployee.setHeight(userRequest.getUserRequestDetail().getAddtionalDetails().getHeight());
		}
		if (null != userRequest.getUserRequestDetail().getAddtionalDetails().getSpouseName()) {
			mEmployee.setSpouseName(userRequest.getUserRequestDetail().getAddtionalDetails().getSpouseName());
		}
		if (null != userRequest.getUserRequestDetail().getAddtionalDetails().getAge()) {
			mEmployee.setAge(userRequest.getUserRequestDetail().getAddtionalDetails().getAge());
		}
		if (null != userRequest.getUserRequestDetail().getAddtionalDetails().getCaste()) {
			mEmployee.setCaste(userRequest.getUserRequestDetail().getAddtionalDetails().getCaste());
		}
		if (null != userRequest.getUserRequestDetail().getAddtionalDetails().getMaritalStatus()) {
			mEmployee.setMaritalStatus(userRequest.getUserRequestDetail().getAddtionalDetails().getMaritalStatus());
		}
		if (null != userRequest.getUserRequestDetail().getAddtionalDetails().getGender()) {
			mEmployee.setGender(userRequest.getUserRequestDetail().getAddtionalDetails().getGender());
		}
		mEmployee.setUserId(mUser);

		if (userRequest.getUserRequestDetail().getAddtionalDetails().isDisability() == true) {
			mEmployee.setDisability(userRequest.getUserRequestDetail().getAddtionalDetails().isDisability());
		}
		if (userRequest.getUserRequestDetail().getAddtionalDetails().isActive() == true) {
			mEmployee.setActive(userRequest.getUserRequestDetail().getAddtionalDetails().isActive());
		}
		if (null != userRequest.getUserRequestDetail().getAddtionalDetails().getNoofChildren()) {
			mEmployee.setNoofChildren(userRequest.getUserRequestDetail().getAddtionalDetails().getNoofChildren());
		}

		return mEmployee;
	}

	public MEmployee primaryAddressValidation(MUser mUser, UserRequest userRequest, boolean newUser,
			MEmployee mEmployee) throws UserManagementException {
		EmployeeAdressDetail addDetails = null;
		EmployeeAddress addressDatase = null;
		EmployeeAddress oldaddressDatase = null;
		Set<EmployeeAddress> addressDataseList = null;
		MEmployee e = null;
		List<EmployeeAdressDetail> requestAdress = userRequest.getUserRequestDetail().getEmployeeAddressDetails();
		if (null == requestAdress || requestAdress.size() <= 0) {
			throw new UserManagementException("Invalid Address Details");
		}
		if (newUser) {
			addressDataseList = new HashSet<EmployeeAddress>();
			for (EmployeeAdressDetail a : requestAdress) {
				addressDatase = new EmployeeAddress();
				addressDatase.setIspresent(a.isPresentAddress());
				addressDatase.setAddress1(a.getAddress1());
				addressDatase.setAddress2(a.getAddress2());
				addressDatase.setCity(a.getCity());
				addressDatase.setEmailAddress(a.getEmail());
				addressDatase.setEmergencyContact(a.getEmergencyContact());
				addressDatase.setPincode(a.getPincode());
				addressDatase.setState(a.getState());
				addressDatase.setMemployee(mEmployee);
				addressDataseList.add(addressDatase);
			}
			mEmployee.setEmployeeAddress(addressDataseList);

		} else if (!newUser) {
			e = new MEmployee();
			e = empRepo.getEmployeeByUserId(mEmployee.getUserId().getId());
			addressDataseList = new HashSet<EmployeeAddress>();
			if (e.getEmployeeAddress() != null) {
				for (EmployeeAdressDetail a : requestAdress) {
					for (EmployeeAddress em : e.getEmployeeAddress()) {
						if (a.getId() != null) {
							addressDatase = new EmployeeAddress();
							addressDatase = em;
							addressDatase.setIspresent(a.isPresentAddress());
							addressDatase.setAddress1(a.getAddress1());
							addressDatase.setAddress2(a.getAddress2());
							addressDatase.setCity(a.getCity());
							addressDatase.setEmailAddress(a.getEmail());
							addressDatase.setEmergencyContact(a.getEmergencyContact());
							addressDatase.setPincode(a.getPincode());
							addressDatase.setState(a.getState());
							addressDataseList.add(addressDatase);
						} else if (a.getId() == null) {
							if (a.isPresentAddress() && em.isIspresent()) {
								addressDatase = new EmployeeAddress();
								oldaddressDatase = new EmployeeAddress();
								oldaddressDatase = em;
								oldaddressDatase.setActive(false);
								oldaddressDatase.setIspresent(false);
								addressDatase.setIspresent(true);
								addressDatase.setActive(true);
								addressDatase.setAddress1(a.getAddress1());
								addressDatase.setAddress2(a.getAddress2());
								addressDatase.setCity(a.getCity());
								addressDatase.setEmailAddress(a.getEmail());
								addressDatase.setEmergencyContact(a.getEmergencyContact());
								addressDatase.setPincode(a.getPincode());
								addressDatase.setState(a.getState());
								addressDatase.setMemployee(mEmployee);
								addressDataseList.add(addressDatase);
								addressDataseList.add(oldaddressDatase);

							} else if (!a.isPresentAddress() && !em.isIspresent()) {

								addressDatase = new EmployeeAddress();
								oldaddressDatase = new EmployeeAddress();
								oldaddressDatase = em;
								oldaddressDatase.setActive(false);
								oldaddressDatase.setIspresent(false);
								addressDatase.setIspresent(false);
								addressDatase.setActive(true);
								addressDatase.setAddress1(a.getAddress1());
								addressDatase.setAddress2(a.getAddress2());
								addressDatase.setCity(a.getCity());
								addressDatase.setEmailAddress(a.getEmail());
								addressDatase.setEmergencyContact(a.getEmergencyContact());
								addressDatase.setPincode(a.getPincode());
								addressDatase.setState(a.getState());
								addressDatase.setMemployee(mEmployee);
								addressDataseList.add(addressDatase);
								addressDataseList.add(oldaddressDatase);
							}
						}
					}
				}
				mEmployee.setEmployeeAddress(addressDataseList);
			}

		}

		return mEmployee;
	}

	public MUser secondaryValidation(MUser mUser, UserRequest userRequest, boolean newUser)
			throws UserManagementException {

		MUser userValidation = null;

		if (newUser) {
			userValidation = userRepo.findByPhoneNumber((userRequest.getUserRequestDetail().getPhoneNo()));
			if (null != userValidation) {
				throw new UserManagementException("Phone Number already exists!!!");
			} else {
				mUser.setPhoneNumber(((userRequest.getUserRequestDetail().getPhoneNo())));

			}
			userValidation = null;
			userValidation = userRepo.findByEmail(userRequest.getUserRequestDetail().getEmail());
			if (null != userValidation) {
				throw new UserManagementException("Email id already exists!!!");

			} else {
				mUser.setEmail(userRequest.getUserRequestDetail().getEmail());
			}
		} else if (!newUser) {
			if (mUser.getId() != null && !mUser.getPhoneNumber().toString()
					.equals(userRequest.getUserRequestDetail().getPhoneNo().toString())) {

				userValidation = userRepo.findByPhoneNumber((userRequest.getUserRequestDetail().getPhoneNo()));
				if (null != userValidation) {
					throw new UserManagementException("Phone Number already exists!!!");
				} else {
					mUser.setPhoneNumber(((userRequest.getUserRequestDetail().getPhoneNo())));

				}
			}
			if (mUser.getId() != null
					&& !mUser.getEmail().toString().equals(userRequest.getUserRequestDetail().getEmail().toString())) {
				userValidation = null;
				userValidation = userRepo.findByEmail(userRequest.getUserRequestDetail().getEmail());
				if (null != userValidation) {
					throw new UserManagementException("Email id already exists!!!");

				} else {
					mUser.setEmail(userRequest.getUserRequestDetail().getEmail());
				}
			}

		}

		return mUser;
	}

	public MUser createUserName(MUser user, UserRequest userRequest) throws UserManagementException {
		StringBuilder userName = new StringBuilder();
		userName.append(userRequest.getUserRequestDetail().getFirstName().toUpperCase().charAt(0));
		userName.append(userRequest.getUserRequestDetail().getLastName().toUpperCase().charAt(0));
		userName.append(userRequest.getUserRequestDetail().getLastName().toLowerCase().substring(1));
		int count = 0;
		List<MUser> userNameList = userRepo.findByUserName(user.getUserName());
		if (null != userNameList) {
			count = userNameList.size();
		}
		if (count > 0) {
			userName = userName.append(count);
		}
		user.setUserName(userName.toString());
		return user;
	}

	public MEmployee validateQualifiactionDetails(MEmployee mEmployee, UserRequest userRequest, boolean newUser,
			MUser mUser) throws UserManagementException {
		List<EmployeeQualificationDetails> employeeQualificationDetails = null;
		employeeQualificationDetails = userRequest.getUserRequestDetail().getEmployeeQualificationDetails();
		if (null == employeeQualificationDetails || employeeQualificationDetails.size() <= 0)
			throw new UserManagementException("Qualification Details not found for employee");
		EmployeeQualificationDetails epd = null;
		List<EmployeeQualification> listfromDb = null;
		Set<EmployeeQualification> listToSave = null;
		List<EmployeeQualificationDetails> newReqObjects;
		List<EmployeeQualificationDetails> existingReqObjectsToBeUpdated;
		Map<Long, EmployeeQualificationDetails> dataExistInDb = new HashMap<>();
		EmployeeQualification eql = null;
		qualificationIdsToDelete = new HashSet<Long>();
		if (newUser) {
			listToSave = new HashSet<EmployeeQualification>();
			for (EmployeeQualificationDetails e : employeeQualificationDetails) {
				eql = new EmployeeQualification();
				eql.setCategory(e.getCategory());
				eql.setCourseName(e.getCourseName());
				eql.setPeriodFrom(e.getPeriodFrom());
				eql.setPeriodTo(e.getPeriodTo());
				eql.setUniversityName(e.getUniversityName());
				eql.setMemployee(mEmployee);
				listToSave.add(eql);
			}

			mEmployee.setEmployeeQualification(listToSave);
		} else if (!newUser) {
			listToSave = new HashSet<EmployeeQualification>();
			listfromDb = equlaiRepo.getAllEducationByEmployeeId(mEmployee.getId());
			if (null != listfromDb) {
				newReqObjects = new ArrayList<EmployeeQualificationDetails>();
				existingReqObjectsToBeUpdated = new ArrayList<EmployeeQualificationDetails>();
				for (EmployeeQualificationDetails e : employeeQualificationDetails) {
					if (e.getId() == null) {
						newReqObjects.add(e);
					} else if (e.getId() != null) {
						dataExistInDb.put(e.getId(), e);
					}
				}
				// Old Object Updated
				for (EmployeeQualification e : listfromDb) {
					if (dataExistInDb.containsKey(e.getId())) {
						existingReqObjectsToBeUpdated.add(dataExistInDb.get(e.getId()));
						epd = new EmployeeQualificationDetails();
						epd = dataExistInDb.get(e.getId());
						e.setCategory(epd.getCategory());
						e.setCourseName(epd.getCourseName());
						e.setPeriodFrom(epd.getPeriodFrom());
						e.setPeriodTo(epd.getPeriodTo());
						e.setUniversityName(epd.getUniversityName());
						e.setMemployee(mEmployee);
						listToSave.add(e);
					} else {
						qualificationIdsToDelete.add(e.getId());
					}
				}
				// New Object to be Inserted
				for (EmployeeQualificationDetails e : newReqObjects) {
					eql = new EmployeeQualification();
					eql.setCategory(e.getCategory());
					eql.setCourseName(e.getCourseName());
					eql.setPeriodFrom(e.getPeriodFrom());
					eql.setPeriodTo(e.getPeriodTo());
					eql.setUniversityName(e.getUniversityName());
					eql.setMemployee(mEmployee);
					listToSave.add(eql);
				}
			}
			mEmployee.setEmployeeQualification(listToSave);
		}
		return mEmployee;
	}

	@Transactional
	@Modifying
	private void deleteEmployeeQulaificationById(Set<Long> ids) {
		equlaiRepo.deleteEmployeequalifiactionByIds(ids);
	}

	public MEmployee validatePostingDetails(MEmployee mEmployee, UserRequest userRequest, boolean newUser, MUser mUser)
			throws UserManagementException, ParseException {
		List<EmployeePostingDetails> employeePostingDetails = null;
		List<EmployeePostingDetails>employeePostingDetailsCopy = null;
		String joinDate = userRequest.getUserRequestDetail().getAddtionalDetails().getJoiningDate();
		employeePostingDetails = userRequest.getUserRequestDetail().getEmployeePostingDetails();
		employeePostingDetailsCopy = userRequest.getUserRequestDetail().getEmployeePostingDetails();
		for (EmployeePostingDetails e : employeePostingDetails) {
			try {
				Date joinDat = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH).parse(joinDate);
				if (null == e.getPeriodFrom() || e.getPeriodFrom().isEmpty())
					throw new UserManagementException("Start date not found!!!");
				Date startDate = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH).parse(e.getPeriodFrom());

				Date endDate = null;
				if (null != e.getPeriodTo() && !e.getPeriodTo().isEmpty()) {
					endDate = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH).parse(e.getPeriodTo());
				}
				if (joinDat.compareTo(startDate) > 0)
					throw new UserManagementException("Joining Date should be before Start date!!!");
				if (null != endDate  && startDate.compareTo(endDate) > 0)
					throw new UserManagementException("Posting Start Date cannot be after posting End date!!!");
			} catch (ParseException e1) {
				e1.printStackTrace();
			}
		}
		for(EmployeePostingDetails e : employeePostingDetails) {
			for(EmployeePostingDetails e1 : employeePostingDetailsCopy) {
				if((e.getOffice_id()==e1.getOffice_id())&& (e.getDesignationId()==e1.getDesignationId())){
					throw new UserManagementException("User Posting designation details and office details are overlapping!!!");
				}
			}
		}
		if (null == employeePostingDetails || employeePostingDetails.size() <= 0)
			throw new UserManagementException("Posting details not found for employess");
		EmployeePostingDetails epd = null;
		Set<MPosting> listFromDb = null;
		Set<MPosting> listToSave = null;
		Set<EmployeePostingDetails> epdCompare = null;
		MPosting eql = null;
		List<MOffice> offList = new ArrayList<MOffice>();
		List<MDesignation> desgList = new ArrayList<MDesignation>();
		List<MDistrict> disList = new ArrayList<MDistrict>();
		offList = mofficeRepo.findAll();
		desgList = designationRepo.findAll();
		disList = districtRepo.findAll();
		Map<Long, MDistrict> disMap = new HashMap<Long, MDistrict>();
		Map<Long, MDesignation> desgMap = new HashMap<Long, MDesignation>();
		Map<Long, MOffice> offMap = new HashMap<Long, MOffice>();
		for (MOffice e : offList) {
			offMap.put(e.getId(), e);
		}
		for (MDistrict e : disList) {
			disMap.put(e.getId(), e);
		}
		for (MDesignation e : desgList) {
			desgMap.put(e.getId(), e);
		}
		List<EmployeePostingDetails> newReqObjects;
		List<EmployeePostingDetails> existingReqObjectsToBeUpdated;
		Map<Long, EmployeePostingDetails> dataExistInDb = new HashMap<>();
		if (newUser) {
			listToSave = new HashSet<MPosting>();
			for (EmployeePostingDetails e : employeePostingDetails) {
				if (e.isActive())
				eql = new MPosting();
				eql.setPeriodFrom(e.getPeriodFrom());
				eql.setPostingType(e.isPostingType());
				eql.setMOffice(offMap.get(e.getOffice_id()));
				eql.setMDistrict(disMap.get(e.getDistrict_id()));
				eql.setMDesignation(desgMap.get(e.getDesignationId()));
				eql.setMemployee(mEmployee);
				listToSave.add(eql);
			}
			mEmployee.setMposting(listToSave);
		} else if (!newUser) {
			epdCompare = new HashSet<EmployeePostingDetails>();
			listToSave = new HashSet<MPosting>();
			listFromDb = mEmployee.getMposting();
			for(MPosting e:listFromDb) {
				for(EmployeePostingDetails e1:epdCompare) {
					if((e.getMOffice().getId()== e1.getOffice_id())&&(e.getMDesignation().getId()==e1.getDesignationId())){
						throw new UserManagementException("User Posting designation details and office details are overlapping!!!");
					}
				}
			}
			if (listFromDb != null) {
				newReqObjects = new ArrayList<EmployeePostingDetails>();
				existingReqObjectsToBeUpdated = new ArrayList<EmployeePostingDetails>();
				for (EmployeePostingDetails e : employeePostingDetails) {
					if (e.getId() == null) {
						newReqObjects.add(e);
					} else if (e.getId() != null) {
						dataExistInDb.put(e.getId(), e);
					}
				}
				for (MPosting e : listFromDb) {
					if (dataExistInDb.containsKey(e.getId())) {
						existingReqObjectsToBeUpdated.add(dataExistInDb.get(e.getId()));
						epd = new EmployeePostingDetails();
						epd = dataExistInDb.get(e.getId());
						e.setMDesignation(desgMap.get(epd.getDesignationId()));
						e.setMDistrict(disMap.get(epd.getDistrict_id()));
						e.setMOffice(offMap.get(epd.getOffice_id()));
						e.setPeriodFrom(epd.getPeriodFrom());
						e.setPeriodTo(epd.getPeriodTo());
						e.setPostingType(epd.isPostingType());
						e.setMemployee(mEmployee);
						listToSave.add(e);
					}
				}
				for (EmployeePostingDetails e : employeePostingDetails) {
					eql = new MPosting();
					eql.setMDesignation(desgMap.get(e.getDesignationId()));
					eql.setMDistrict(disMap.get(e.getDistrict_id()));
					eql.setMOffice(offMap.get(e.getOffice_id()));
					eql.setPeriodFrom(e.getPeriodFrom());
					eql.setPostingType(e.isPostingType());
					eql.setMemployee(mEmployee);
					listToSave.add(eql);
				}
			}
			mEmployee.setMposting(listToSave);
		}
		return mEmployee;
	}

	public MEmployee validateOtherDetails(MEmployee mEmployee, UserRequest userRequest, boolean newUser, MUser mUser)
			throws UserManagementException {
		EmployeeOtherInfo e = null;
		EmployeeOtherInfoDetails eoi = null;
		if (newUser) {
			e = new EmployeeOtherInfo();
			e.setBankAccount(userRequest.getUserRequestDetail().getOtherInfoDetails().getBankAccount());
			e.setBankNameList(userRequest.getUserRequestDetail().getOtherInfoDetails().getBankName());
			e.setHealth(userRequest.getUserRequestDetail().getOtherInfoDetails().getHealth());
			e.setOtherInformation(userRequest.getUserRequestDetail().getOtherInfoDetails().getOtherInformation());
			e.setPanCard(userRequest.getUserRequestDetail().getOtherInfoDetails().getPanCard());
			e.setVoterId(userRequest.getUserRequestDetail().getOtherInfoDetails().getVoterCard());
			e.setMemployee(mEmployee);
			mEmployee.setEmployeeOtherInfo(e);
		}
		if (!newUser) {
			e = new EmployeeOtherInfo();
			eoi = new EmployeeOtherInfoDetails();
			eoi = userRequest.getUserRequestDetail().getOtherInfoDetails();
			e = mEmployee.getEmployeeOtherInfo();
			if (null != e) {
				e.setBankAccount(eoi.getBankAccount());
				e.setBankNameList(eoi.getBankName());
				e.setHealth(eoi.getHealth());
				e.setOtherInformation(eoi.getOtherInformation());
				e.setPanCard(eoi.getPanCard());
				e.setVoterId(eoi.getVoterCard());
				e.setMemployee(mEmployee);
				mEmployee.setEmployeeOtherInfo(e);
			}

		}
		return mEmployee;
	}
}
