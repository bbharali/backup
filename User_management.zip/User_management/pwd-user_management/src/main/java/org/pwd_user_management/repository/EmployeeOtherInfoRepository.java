package org.pwd_user_management.repository;

import org.pwd_user_management.entity.EmployeeOtherInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface EmployeeOtherInfoRepository extends JpaRepository<EmployeeOtherInfo, Long>{
	
	@Query("From EmployeeOtherInfo em where em.memployee.id  = ?1")
	EmployeeOtherInfo getAllEducationByEmployeeId( Long id);
}
