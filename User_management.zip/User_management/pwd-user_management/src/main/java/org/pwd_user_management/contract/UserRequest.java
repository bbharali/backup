package org.pwd_user_management.contract;

import org.egov.common.contract.request.RequestInfo;
import org.pwd_user_management.model.UserRequestDetail;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor	

public class UserRequest {

	@JsonProperty("RequestInfo")
	private RequestInfo requestInfo;
	@JsonProperty("requestParams")
	private UserRequestDetail userRequestDetail;

}
