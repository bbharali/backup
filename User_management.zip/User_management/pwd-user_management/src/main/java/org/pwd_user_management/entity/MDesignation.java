/**
 * 
 */
package org.pwd_user_management.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.pwd_user_management.model.AbstractAuditable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

@Entity
@Table(name = "m_designation")
@SequenceGenerator(name = MDesignation.SEQ, sequenceName = MDesignation.SEQ, allocationSize = 1)
public class MDesignation extends AbstractAuditable {
	public static final String SEQ = "seq_designation";
	private static final long serialVersionUID = 7977534010758407945L;
	@Id
	@GeneratedValue(generator = MDesignation.SEQ, strategy = GenerationType.SEQUENCE)
	private Long id;
	@Column(name = "designation_name")
	private String designationName;
	@Column(name = "designation_code")
	private String designationCode;
	@Column(name = "is_active")
	private boolean isActive;
	@Column(name = "associated_group")
	private String associatedGroup;
}