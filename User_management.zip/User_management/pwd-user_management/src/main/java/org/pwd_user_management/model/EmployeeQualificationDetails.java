package org.pwd_user_management.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class EmployeeQualificationDetails {
	@JsonProperty("id")
	private Long id;
	@JsonProperty("periodFrom")
	private String periodFrom;
	@JsonProperty("periodTo")
	private String periodTo;
	@JsonProperty("category")
	private String category;
	@JsonProperty("universityName")
	private String universityName;
	@JsonProperty("courseName")
	private String courseName;
}
