package org.pwd_user_management.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "m_posting")
@SequenceGenerator(name = MPosting.SEQ, sequenceName = MPosting.SEQ, allocationSize = 1)
public class MPosting {
	public static final String SEQ = "seq_m_posting";
	private static final long serialVersionUID = 7977534010758407945L;
	@Id
	@GeneratedValue(generator = MPosting.SEQ, strategy = GenerationType.SEQUENCE)
	private Long id;
	@Column(name="period_from")
	private String periodFrom;
	@Column(name="period_to")
	private String periodTo;
	@OneToOne
	@JoinColumn(name="designation_id")
	private MDesignation mDesignation;
	@OneToOne
	@JoinColumn(name="office_id")
	private MOffice mOffice;
	@OneToOne
	@JoinColumn(name="district_id")
	private MDistrict mDistrict;
	@ManyToOne
	@JoinColumn(name="employee_id")
	private MEmployee memployee;
	@Column(name="posting_type")
	private boolean postingType;
	@Column(name="is_active")
	private boolean Isactive;
	
}
