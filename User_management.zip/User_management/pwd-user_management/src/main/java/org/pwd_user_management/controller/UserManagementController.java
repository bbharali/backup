package org.pwd_user_management.controller;

import org.pwd_user_management.contract.UserRequest;
import org.pwd_user_management.contract.UserResponse;
import org.pwd_user_management.service.UserMangementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import lombok.extern.slf4j.Slf4j;

@RestController
@Validated
@RequestMapping("/user")
@Slf4j
public class UserManagementController {
	
	@Autowired
	UserMangementService userService;
	@PostMapping(value ="/createUser")
	@ResponseBody
	public ResponseEntity<?> createUser(@RequestBody UserRequest request,BindingResult errors)
	{
		UserResponse userResponse = new UserResponse();
		
		try {
			userService.createUser(request, userResponse);
			userResponse.setStatus("SUCCESS");
			userResponse.setMsg("User Data saved successfully!!!");
			
		}catch(Exception e) {
			e.printStackTrace();
			userResponse.setStatus("ERROR");
			userResponse.setMsg(e.getMessage());
			return new ResponseEntity<>(userResponse, HttpStatus.OK);
		}
		return new ResponseEntity<>(HttpStatus.OK);
	}

}
