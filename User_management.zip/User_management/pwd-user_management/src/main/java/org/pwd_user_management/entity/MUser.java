package org.pwd_user_management.entity;

import java.math.BigInteger;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

@Entity
@Table(name = "m_user")
@SequenceGenerator(name = MUser.SEQ, sequenceName = MUser.SEQ, allocationSize = 1)

public class MUser {
	public static final String SEQ = "seq_m_user";
	private static final long serialVersionUID = 7977534010758407945L;
	@Id
	@GeneratedValue(generator = MUser.SEQ, strategy = GenerationType.SEQUENCE)
	private Long id;
	@Column(name ="first_name")
	private String fname;
	@Column(name="user_name")
	private String userName;
	@Column(name = "password")
	private String password;
	@Column(name ="middle_name")
	private String mname;
	@Column(name ="last_name")
	private String lname;
	@Column(name="email")
	private String email;
	@Column(name ="phone_no")
	private BigInteger phoneNumber;
	@Column(name="DOB")
	private String dob;	
	@Column(name ="prefix")
	private String mprefix;
	@Column(name="user_type")
	private String userType;
	@Column(name="is_active")
	private boolean isActive;
	
	@OneToOne(mappedBy = "userId",cascade = CascadeType.ALL,targetEntity = MEmployee.class)
	private MEmployee mEmployee;
}
