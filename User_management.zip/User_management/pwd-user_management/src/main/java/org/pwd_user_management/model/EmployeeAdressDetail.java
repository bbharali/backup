package org.pwd_user_management.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class EmployeeAdressDetail {
	private String id;
	@JsonProperty("address1")
	private String address1;
	@JsonProperty("address2")
	private String address2;
	@JsonProperty("city")
	private String city;
	@JsonProperty("state")
	private String state;
	@JsonProperty("pincode")
	private String pincode;
	@JsonProperty("email")
	private String email;
	@JsonProperty("emergencyContact")
	private String emergencyContact;
	@JsonProperty("isPresentAddress")
	private boolean presentAddress;
}
