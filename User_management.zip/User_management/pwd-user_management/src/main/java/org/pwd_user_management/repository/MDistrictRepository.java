/**
 * 
 */
package org.pwd_user_management.repository;


import org.pwd_user_management.entity.MDistrict;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MDistrictRepository extends JpaRepository<MDistrict, Long>{

	MDistrict findById(long id);
	MDistrict findByDistrictName(String name);
	MDistrict findByCode(String code);
	
}
