package org.pwd_user_management.repository;

import java.math.BigInteger;
import java.util.List;

import org.pwd_user_management.entity.MUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<MUser, Long> {
	MUser findById(long id);
	

	@Query(value = "from MUser m where m.phoneNumber=?1")
	MUser findByPhoneNumber(BigInteger id);

	@Query(value = "from MUser m where m.email=?1")
	MUser findByEmail(String id);

	@Query(value = "from MUser m where m.userName LIKE ?1% ")
	List<MUser> findByUserName(String username);

}
