/**
 * 
 */
package org.pwd_user_management.repository;



import org.pwd_user_management.entity.MDesignation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MDesignationRepository extends JpaRepository<MDesignation, Long>{
	MDesignation findById(long id);
	MDesignation findByDesignationName(String name);
	MDesignation findByDesignationCode(String code);
}
