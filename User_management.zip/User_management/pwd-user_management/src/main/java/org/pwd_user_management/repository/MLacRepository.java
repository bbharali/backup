/**
 * 
 */
package org.pwd_user_management.repository;

import org.pwd_user_management.entity.MLac;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MLacRepository extends JpaRepository<MLac, Long>{
	MLac findById(long id);
	MLac findByBsConstituency(String bsConstituency);
	MLac findByLsConstituency(String lsConstituency);
	MLac findByCode(String code);
}
