package org.pwd_user_management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PwdUserManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(PwdUserManagementApplication.class, args);
	}

}
