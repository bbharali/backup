/**
 * 
 */
package org.pwd_user_management.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.pwd_user_management.model.AbstractAuditable;


@Entity
@Table(name = "m_district")
@SequenceGenerator(name = MDistrict.SEQ, sequenceName = MDistrict.SEQ, allocationSize = 1)
public class MDistrict extends AbstractAuditable {
	public static final String SEQ = "seq_district";
	private static final long serialVersionUID = 7977534010758407945L;
	@Id
	@GeneratedValue(generator = MDistrict.SEQ, strategy = GenerationType.SEQUENCE)
	private Long id;
	@Column(name = "district_name")
	private String districtName;
	@Column(name = "is_active")
	private boolean isActive;
	private String code;

	/**
	 * 
	 */
	public MDistrict() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MDistrict(Long id, String districtName, boolean isActive, String code) {
		super();
		this.id = id;
		this.districtName = districtName;
		this.isActive = isActive;
		this.code = code;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the districtName
	 */
	public String getDistrictName() {
		return districtName;
	}

	/**
	 * @param districtName the districtName to set
	 */
	public void setDistrictName(String districtName) {
		this.districtName = districtName;
	}

	/**
	 * @return the isActive
	 */
	public boolean isActive() {
		return isActive;
	}

	/**
	 * @param isActive the isActive to set
	 */
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

}
