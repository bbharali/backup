package org.pwd_user_management.contract;

import java.util.List;

import org.egov.common.contract.response.ResponseInfo;
import org.pwd_user_management.model.UserResponseDetail;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class UserResponse {
	@JsonProperty("ResponseInfo")
	private ResponseInfo responseInfo = null;	
	@JsonProperty("userResponse")
	private List<UserResponseDetail> dprDataList;
	private String status;
	private String msg;

}
