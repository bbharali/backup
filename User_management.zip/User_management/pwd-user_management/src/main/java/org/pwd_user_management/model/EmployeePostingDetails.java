package org.pwd_user_management.model;

import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.pwd_user_management.entity.MEmployee;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class EmployeePostingDetails {
	@JsonProperty("id")
	private Long id;
	@JsonProperty("periodFrom")
	private String periodFrom;
	@JsonProperty("periodTo")
	private String periodTo;
	@JsonProperty("mDesignation")
	private Long designationId;
	@JsonProperty("officeId")
	private Long office_id;
	@JsonProperty("districtId")
	private Long district_id;
	@JsonProperty("postingType")
	private boolean postingType;
	@JsonProperty("isActive")
	private boolean isActive;
}
