package org.pwd_user_management.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

@Entity
@Table(name = "m_employee_qualification")
@SequenceGenerator(name = EmployeeQualification.SEQ, sequenceName = EmployeeQualification.SEQ, allocationSize = 1)
public class EmployeeQualification {
	
	public static final String SEQ = "seq_m_qualification";
	private static final long serialVersionUID = 7977534010758407945L;
	@Id
	@GeneratedValue(generator = EmployeeQualification.SEQ, strategy = GenerationType.SEQUENCE)
	private Long id;
	@Column(name="period_from")
	private String periodFrom;
	@Column(name="period_to")
	private String periodTo;
	@Column(name="category")
	private String category;
	@Column(name="university_name")
	private String  universityName;
	@Column(name="course_name")
	private String courseName;
	@ManyToOne
	@JoinColumn(name = "employee_id")
	private MEmployee memployee;
	

}
