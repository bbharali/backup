package org.pwd_user_management.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

@Entity
@Table(name = "m_bank_name_list")
@SequenceGenerator(name = BankNameList.SEQ, sequenceName = BankNameList.SEQ, allocationSize = 1)

public class BankNameList {
	public static final String SEQ = "seq_m_bank_name_list";
	private static final long serialVersionUID = 7977534010758407945L;
	@Id
	@GeneratedValue(generator = BankNameList.SEQ, strategy = GenerationType.SEQUENCE)
	private Long id;
	@Column(name="bank_name")
	private String bankName;
}
