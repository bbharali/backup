package org.pwd_user_management.model;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeAdditionalDetailsModel {
	private String id;
	@JsonProperty("fatherName")
	private String fatherName;
	@JsonProperty("uploadPhoto")
	private String uploadPhoto;
	@JsonProperty("retirementDate")
	private String retirementDate;
	@JsonProperty("townOfBirth")
	private String townOfBirth;
	@JsonProperty("stateOfBirth")
	private String stateOfBirth;
	@JsonProperty("religion")
	private String religion;
	@JsonProperty("nationality")
	private String nationality;
	@JsonProperty("identification")
	private String identification;
	@JsonProperty("bloodGroup")
	private String bloodGroup;
	@JsonProperty("spouseName")
	private String spouseName;
	@JsonProperty("noofChildren")
	private Long noofChildren;
	@JsonProperty("height")
	private BigDecimal height;
	@JsonProperty("age")
	private Long age;
	@JsonProperty("caste")
	private String caste;
	@JsonProperty("maritalStatus")
	private String maritalStatus;
	@JsonProperty("gender")
	private String gender;
	@JsonProperty("userId")
	private Long userId;
	@JsonProperty("disability")
	private boolean disability;
	@JsonProperty("isActive")
	private boolean isActive;
	@JsonProperty("joiningDate")
	private String joiningDate;

	

}
