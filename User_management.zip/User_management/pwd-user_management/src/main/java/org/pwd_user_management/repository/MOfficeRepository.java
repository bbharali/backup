package org.pwd_user_management.repository;
import java.util.List;

import org.pwd_user_management.entity.MOffice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface MOfficeRepository extends JpaRepository<MOffice, Long> {
	MOffice findById(long id);
	MOffice findByOfficeName(String officeName);
	MOffice findByOfficeType(String officeType);
	List<MOffice> findByParentOfficeId(MOffice ofc);
	MOffice findByDistrict(long districtId);
	MOffice findByCode(String code);
	
}
