package org.pwd_user_management.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.pwd_user_management.model.AbstractAuditable;


@Entity
@Table(name = "m_office")
@SequenceGenerator(name = MOffice.SEQ, sequenceName = MOffice.SEQ, allocationSize = 1)
public class MOffice extends AbstractAuditable {
	public static final String SEQ = "seq_m_office";
	private static final long serialVersionUID = 7977534010758407945L;
	@Id
	@GeneratedValue(generator = MOffice.SEQ, strategy = GenerationType.SEQUENCE)
	private Long id;
	@Column(name = "office_name")
	private String officeName;
	@Column(name = "office_type")
	private String officeType;
	@ManyToOne
	@JoinColumn(name = "parent_office_id")
	private MOffice parentOfficeId;
	@ManyToOne
	@JoinColumn(name = "district_id")
	private MDistrict district;
	@Column(name = "wing_id")
	private String wingId;
	@Column(name = "is_active")
	private boolean isActive;
	private String code;
	@Column(name = "ddo_code")
	private String ddoCode;
	@Column(name = "ddo_name")
	private String ddoName;

	public MOffice() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MOffice(Long id, String officeName, String officeType, MOffice parentOfficeId, MDistrict district,
			String wingId, boolean isActive, MLac lac, String code, String ddoCode, String ddoName) {
		super();
		this.id = id;
		this.officeName = officeName;
		this.officeType = officeType;
		this.parentOfficeId = parentOfficeId;
		this.district = district;
		this.wingId = wingId;
		this.isActive = isActive;
		this.code = code;
		this.ddoCode = ddoCode;
		this.ddoName = ddoName;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getOfficeName() {
		return officeName;
	}

	public void setOfficeName(String officeName) {
		this.officeName = officeName;
	}

	public String getOfficeType() {
		return officeType;
	}

	public void setOfficeType(String officeType) {
		this.officeType = officeType;
	}

	public MDistrict getDistrict() {
		return district;
	}

	public void setDistrict(MDistrict district) {
		this.district = district;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public MOffice getParentOfficeId() {
		return parentOfficeId;
	}

	public void setParentOfficeId(MOffice parentOfficeId) {
		this.parentOfficeId = parentOfficeId;
	}

	public String getWingId() {
		return wingId;
	}

	public void setWingId(String wingId) {
		this.wingId = wingId;
	}

	public String getDdoCode() {
		return ddoCode;
	}

	public void setDdoCode(String ddoCode) {
		this.ddoCode = ddoCode;
	}

	public String getDdoName() {
		return ddoName;
	}

	public void setDdoName(String ddoName) {
		this.ddoName = ddoName;
	}

}
