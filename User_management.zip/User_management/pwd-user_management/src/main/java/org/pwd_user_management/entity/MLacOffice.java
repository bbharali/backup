package org.pwd_user_management.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.pwd_user_management.model.AbstractAuditable;


@Entity
@Table(name = "m_lac_office_map")
@SequenceGenerator(name = MLacOffice.SEQ, sequenceName = MLacOffice.SEQ, allocationSize = 1)
public class MLacOffice extends AbstractAuditable {
	public static final String SEQ = "seq_m_lac_office";
	private static final long serialVersionUID = 7977534010758407945L;
	@Id
	@GeneratedValue(generator = MLacOffice.SEQ, strategy = GenerationType.SEQUENCE)
	private Long id;
	@ManyToOne
	@JoinColumn(name = "office_id")
	private MOffice mOffice;
	@ManyToOne
	@JoinColumn(name = "lac_id")
	private MLac mLac;
	@Column(name = "is_active")
	private boolean isActive;

	public MLacOffice() {
		super();
	}

	public MLacOffice(Long id, MOffice mOffice, MLac mLac, boolean isActive) {
		super();
		this.id = id;
		this.mOffice = mOffice;
		this.mLac = mLac;
		this.isActive = isActive;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public MOffice getmOffice() {
		return mOffice;
	}

	public void setmOffice(MOffice mOffice) {
		this.mOffice = mOffice;
	}

	public MLac getmLac() {
		return mLac;
	}

	public void setmLac(MLac mLac) {
		this.mLac = mLac;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

}
