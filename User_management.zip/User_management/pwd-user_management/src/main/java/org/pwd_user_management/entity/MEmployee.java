package org.pwd_user_management.entity;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

@Entity
@Table(name = "m_employee")
@SequenceGenerator(name = MEmployee.SEQ, sequenceName = MEmployee.SEQ, allocationSize = 1)

public class MEmployee {
	public static final String SEQ = "seq_m_employee";
	private static final long serialVersionUID = 7977534010758407945L;
	@Id
	@GeneratedValue(generator = MEmployee.SEQ, strategy = GenerationType.SEQUENCE)
	private Long id;
	@Column(name = "father_or_husband_name")
	private String fatherName;
	@Column(name = "upload_photo_url")
	private String uploadPhoto;
	@Column(name = "retirement_date")
	private String retirementDate;
	@Column(name = "town_of_birth")
	private String townOfBirth;
	@Column(name = "state_of_birth")
	private String stateOfBirth;
	@Column(name = "religion")
	private String religion;
	@Column(name = "nationality")
	private String nationality;
	@Column(name = "identification")
	private String identification;
	@Column(name = "blood_group")
	private String bloodGroup;
	@Column(name = "spouse_name")
	private String spouseName;
	@Column(name = "no_of_children")
	private Long noofChildren;
	@Column(name = "height")
	private BigDecimal height;
	@Column(name = "age")
	private Long age;
	@Column(name = "caste")
	private String caste;
	@Column(name = "marital_status")
	private String maritalStatus;
	@Column(name = "gender")
	private String gender;
	@OneToOne
	@JoinColumn(name = "user_id")
	private MUser userId;
	@Column(name = "disability")
	private boolean disability;
	@Column(name = "is_active")
	private boolean isActive;
	@Column(name="joining_date")
	private String joiningDate;
	@OneToMany(mappedBy = "memployee", cascade = CascadeType.ALL, targetEntity = EmployeeQualification.class)
	private Set<EmployeeQualification> employeeQualification;
	@OneToMany(mappedBy = "memployee", cascade = CascadeType.ALL, targetEntity = EmployeeAddress.class)
	private Set<EmployeeAddress> employeeAddress;
	@OneToMany(mappedBy = "memployee", cascade = CascadeType.ALL, targetEntity = MPosting.class)
	private Set<MPosting> mposting;
	@OneToOne(mappedBy = "memployee", cascade = CascadeType.ALL, targetEntity = EmployeeOtherInfo.class)
	private EmployeeOtherInfo employeeOtherInfo;
	
	
}
