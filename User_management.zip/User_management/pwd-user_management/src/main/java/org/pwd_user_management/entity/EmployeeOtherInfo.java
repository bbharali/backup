package org.pwd_user_management.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

@Entity
@Table(name = "employee_other_info")
@SequenceGenerator(name = EmployeeOtherInfo.SEQ, sequenceName = EmployeeOtherInfo.SEQ, allocationSize = 1)
public class EmployeeOtherInfo {
	public static final String SEQ = "seq_employee_other_info";
	private static final long serialVersionUID = 7977534010758407945L;
	@Id
	@GeneratedValue(generator = EmployeeOtherInfo.SEQ, strategy = GenerationType.SEQUENCE)
	private Long id;
	@Column(name = "pan_id")
	private String panCard;
	@Column(name = "voter_id")
	private String voterId;
	@Column(name = "bank_account")
	private String bankAccount;
	@Column(name = "bank_name")
	private String bankNameList;
	@Column(name = "health")
	private String health;
	@Column(name = "other_information")
	private String otherInformation;
	@OneToOne
	@JoinColumn(name="employee_id")
	private MEmployee memployee;
	

}
