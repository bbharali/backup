package org.pwd_user_management.util;

public class UserValidations {

}
