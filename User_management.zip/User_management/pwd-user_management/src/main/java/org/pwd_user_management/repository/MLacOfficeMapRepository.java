package org.pwd_user_management.repository;

import java.util.List;

import org.pwd_user_management.entity.MLac;
import org.pwd_user_management.entity.MLacOffice;
import org.pwd_user_management.entity.MOffice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MLacOfficeMapRepository extends JpaRepository<MLacOffice, Long> {
	List<MLacOffice> findBymLac(MLac lac);
	List<MLacOffice> findBymOffice(MOffice office);
}
