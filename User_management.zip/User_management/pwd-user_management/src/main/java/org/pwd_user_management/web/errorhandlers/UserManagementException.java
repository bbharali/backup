package org.pwd_user_management.web.errorhandlers;

public class UserManagementException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UserManagementException(String errorMessage) {  
		    super(errorMessage);  
	}
}
