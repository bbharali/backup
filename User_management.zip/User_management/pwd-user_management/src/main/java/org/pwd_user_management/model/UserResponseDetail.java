package org.pwd_user_management.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class UserResponseDetail {
	
	@JsonProperty("prefix")
	private String prefix;
	@JsonProperty("firstName")
	private String firstName;
	@JsonProperty("middleName")
	private String middleName;	
	@JsonProperty("lastName")
	private String lastName;
	@JsonProperty("email")
	private String email;	
	@JsonProperty("phoneNo")
	private String phoneNo;	
	@JsonProperty("dob")
	private String dob;
	@JsonProperty("userType")
	private String userType;
	@JsonProperty("isEmployee")
	private String isEmployee;
	@JsonProperty("userName")
	private String userName;
	

}
