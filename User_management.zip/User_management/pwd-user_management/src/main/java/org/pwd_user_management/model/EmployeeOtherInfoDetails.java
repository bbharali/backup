package org.pwd_user_management.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class EmployeeOtherInfoDetails {
	private String id;
	@JsonProperty("panCard")
	private String panCard;
	@JsonProperty("voterCard")
	private String voterCard;
	@JsonProperty("bankAccount")
	private String bankAccount;
	@JsonProperty("bankName")
	private String bankName;
	@JsonProperty("health")
	private String health;
	@JsonProperty("otherInformation")
	private String otherInformation;
	

}
