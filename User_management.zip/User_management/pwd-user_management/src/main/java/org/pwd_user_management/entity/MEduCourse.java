package org.pwd_user_management.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

@Entity
@Table(name = "m_educourse")
@SequenceGenerator(name = MEduCourse.SEQ, sequenceName = MEduCourse.SEQ, allocationSize = 1)
public class MEduCourse {
	
	public static final String SEQ = "seq_m_educourse";
	private static final long serialVersionUID = 7977534010758407945L;
	@Id
	@GeneratedValue(generator = MEduCourse.SEQ, strategy = GenerationType.SEQUENCE)
	private Long id;	
	@Column(name="name")
	private String name;
}
