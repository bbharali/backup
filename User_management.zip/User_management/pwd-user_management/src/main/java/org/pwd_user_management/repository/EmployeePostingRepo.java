package org.pwd_user_management.repository;

import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.pwd_user_management.entity.MPosting;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

public interface EmployeePostingRepo extends JpaRepository<MPosting, Long> {

	@Query("From MPosting em where em.memployee.id = ?1")
	List<MPosting> getAllPostingByEmployeeId(Long id);

	@Modifying
	@Transactional
	@Query("Delete from  MPosting em where em.id in (:id)")
	public void deleteEmployeepostingByIds(Set<Long> id);

	MPosting getAllById(long id);

}
