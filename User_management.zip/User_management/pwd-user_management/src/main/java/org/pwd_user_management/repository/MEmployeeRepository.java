package org.pwd_user_management.repository;

import org.pwd_user_management.entity.MEmployee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface MEmployeeRepository extends JpaRepository<MEmployee, Long> {
	@Query("From MEmployee e where e.userId.id = ?1")
	public MEmployee getEmployeeByUserId(Long id);

}
