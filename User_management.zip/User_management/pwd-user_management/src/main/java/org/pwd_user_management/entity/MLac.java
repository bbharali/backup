/**
 * 
 */
 package org.pwd_user_management.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.pwd_user_management.model.AbstractAuditable;



@Entity
@Table(name = "m_lac")
@SequenceGenerator(name = MLac.SEQ, sequenceName = MLac.SEQ, allocationSize = 1)
public class MLac extends AbstractAuditable {
	public static final String SEQ = "seq_lac";
	private static final long serialVersionUID = 7977534010758407945L;
	@Id
	@GeneratedValue(generator = MLac.SEQ, strategy = GenerationType.SEQUENCE)
	private Long id;
	@Column(name = "bs_constituency")
	private String bsConstituency;
	@Column(name = "ls_constituency")
	private String lsConstituency;
	@Column(name = "is_active")
	private boolean isActive;
	private String code;
	@OneToMany(orphanRemoval = true, cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "mLac", targetEntity = MLacOffice.class)
	private Set<MLacOffice> lacWithOffice;

	/**
	 * 
	 */
	public MLac() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MLac(Long id, String bsConstituency, String lsConstituency, boolean isActive, String code) {
		super();
		this.id = id;
		this.bsConstituency = bsConstituency;
		this.lsConstituency = lsConstituency;
		this.isActive = isActive;
		this.code = code;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the bsConstituency
	 */
	public String getBsConstituency() {
		return bsConstituency;
	}

	/**
	 * @param bsConstituency the bsConstituency to set
	 */
	public void setBsConstituency(String bsConstituency) {
		this.bsConstituency = bsConstituency;
	}

	/**
	 * @return the lsConstituency
	 */
	public String getLsConstituency() {
		return lsConstituency;
	}

	/**
	 * @param lsConstituency the lsConstituency to set
	 */
	public void setLsConstituency(String lsConstituency) {
		this.lsConstituency = lsConstituency;
	}

	/**
	 * @return the isActive
	 */
	public boolean isActive() {
		return isActive;
	}

	/**
	 * @param isActive the isActive to set
	 */
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Set<MLacOffice> getLacWithOffice() {
		return lacWithOffice;
	}

	public void setLacWithOffice(Set<MLacOffice> lacWithOffice) {
			this.lacWithOffice = lacWithOffice;
	}

}
