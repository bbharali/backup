package org.pwd_user_management.model;

import java.math.BigInteger;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class UserRequestDetail {
	
private String id;	
@JsonProperty("prefix")
private String prefix;
@JsonProperty("firstname")
private String firstName;
@JsonProperty("middlename")
private String middleName;
@JsonProperty("lastname")
private String lastName;
@JsonProperty("email")
private String email;
@JsonProperty("phone")
private BigInteger phoneNo;
@JsonProperty("dob")
private String dob;
@JsonProperty("usertype")
private String userType;
@JsonProperty("isActive")
private boolean isActive;
@JsonProperty("additionalDetails")
private EmployeeAdditionalDetailsModel addtionalDetails;
@JsonProperty("employeeEqualification")
private List<EmployeeQualificationDetails> employeeQualificationDetails;
@JsonProperty("employeePosting")
private List<EmployeePostingDetails> employeePostingDetails;
@JsonProperty("address")
private List<EmployeeAdressDetail> employeeAddressDetails;
@JsonProperty("empOtherInfo")
private EmployeeOtherInfoDetails otherInfoDetails;
}
